from django.contrib import admin
from .models import userModel, toDoModel

# Register your models here.
admin.site.register(userModel)
admin.site.register(toDoModel)