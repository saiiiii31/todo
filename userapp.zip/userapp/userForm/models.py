from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class userModel(models.Model):
    fname = models.CharField(max_length=120)
    lname = models.CharField(max_length=120)
    username = models.CharField(max_length=120, unique= True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=120)

    def __str__(self):
        return self.fname


class toDoModel(models.Model):
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    task = models.CharField(max_length=200)

    def __str__(self):
        return f"{self.username.username} - {self.task}"

